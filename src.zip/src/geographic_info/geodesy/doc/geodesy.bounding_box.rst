geodesy.bounding_box
--------------------

.. automodule:: geodesy.bounding_box
   :members:
