Change history
==============

0.5.3 (2018-03-27)
------------------

0.5.2 (2017-04-15)
------------------

0.5.1 (2017-04-15)
------------------

0.5.0 (2017-04-07)
------------------

 * Removed Python setup install_requires option.

0.4.0 (2014-09-18)
------------------

 * Released to Indigo.
 * Remove deprecated geodesy.gen_uuid module (`#4`_).

0.3.2 (2014-08-30)
------------------

 * Released to Indigo.
 * Make C++ template declaration for WGS-84 header compatible with GCC
   4.7 compiler (`#12`_), thanks to Mike Purvis and Dirk Thomas.

0.3.1 (2013-10-03)
------------------

 * Fix ROS Hydro header install problem (`#9`_).

0.3.0 (2013-08-03)
------------------

 * Released to Hydro.
 * Convert to catkin build (`#3`_).
 * Remove unnecessary roscpp and rospy dependencies (`#6`_).

0.2.1 (2012-08-13)
------------------

 * Released to Fuerte.
 * Released to Groovy: 2013-03-27.
 * Use unique_identifier for UUID interfaces.

0.2.0 (2012-06-02)
------------------

 * Many new mapping messages and services added.
 * Use PROJ.4 library for Python geodesy API (C++ API not ported to
   PROJ.4 yet).
 * Released to Electric.

0.1.0 (2012-04-10)
------------------

 * Initial release to Electric.

.. _`#3`: https://github.com/ros-geographic-info/geographic_info/issues/3
.. _`#4`: https://github.com/ros-geographic-info/geographic_info/issues/4
.. _`#6`: https://github.com/ros-geographic-info/geographic_info/issues/6
.. _`#9`: https://github.com/ros-geographic-info/geographic_info/issues/9
.. _`#12`: https://github.com/ros-geographic-info/geographic_info/issues/12
