geographic_info repository
==========================

ROS messages and interfaces for mapping and coordinate conversions,
part of the ROS Geographic Information project.

 * http://en.wikipedia.org/wiki/Geographic_information_system

ROS documentation:

 * http://wiki.ros.org/geographic_info
 * http://wiki.ros.org/geographic_msgs
 * http://wiki.ros.org/geodesy
