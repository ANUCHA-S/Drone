unique_id
---------

.. automodule:: unique_id
   :members:
